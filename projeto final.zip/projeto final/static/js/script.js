document.getElementById("cadastroForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const nome = document.getElementById("nome").value;
    const dataNascimento = document.getElementById("dataNascimento").value;
    const sexo = document.getElementById("sexo").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    if (nome && dataNascimento && sexo && email && senha) {
        alert("Cadastro realizado com sucesso!");
        // Aqui você pode adicionar a lógica para salvar os dados ou enviar para um servidor
    } else {
        alert("Por favor, preencha todos os campos.");
    }
});

document.addEventListener("DOMContentLoaded", function() {
    const diaSelect = document.getElementById("dia");
    const mesSelect = document.getElementById("mes");
    const anoSelect = document.getElementById("ano");

    // Preenche os dias
    for (let i = 1; i <= 31; i++) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = i;
        diaSelect.appendChild(option);
    }

    // Preenche os meses
    const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    meses.forEach((mes, index) => {
        const option = document.createElement("option");
        option.value = index + 1;
        option.textContent = mes;
        mesSelect.appendChild(option);
    });

    // Preenche os anos (ex: de 1900 até o ano atual)
    const anoAtual = new Date().getFullYear();
    for (let i = anoAtual; i >= 1900; i--) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = i;
        anoSelect.appendChild(option);
    }
});

document.getElementById("cadastroForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const nome = document.getElementById("nome").value;
    const dia = document.getElementById("dia").value;
    const mes = document.getElementById("mes").value;
    const ano = document.getElementById("ano").value;
    const sexo = document.getElementById("sexo").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    if (nome && dia && mes && ano && sexo && email && senha) {
        const dataNascimento = `${dia}/${mes}/${ano}`;
        alert(`Cadastro realizado com sucesso!\nData de Nascimento: ${dataNascimento}`);
        // Aqui você pode adicionar a lógica para salvar os dados ou enviar para um servidor
    } else {
        alert("Por favor, preencha todos os campos.");
    }
});
