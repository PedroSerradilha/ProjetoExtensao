
function preencherData() {
    const diaSelect = document.getElementById('dia');
    const mesSelect = document.getElementById('mes');
    const anoSelect = document.getElementById('ano');

    // Preencher os dias (1 a 31)
    for (let i = 1; i <= 31; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        diaSelect.appendChild(option);
    }

    // Preencher os meses (1 a 12)
    const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    meses.forEach((mes, index) => {
        const option = document.createElement('option');
        option.value = index + 1;
        option.textContent = mes;
        mesSelect.appendChild(option);
    });

    // Preencher os anos (1900 até o ano atual)
    const anoAtual = new Date().getFullYear();
    for (let i = anoAtual; i >= 1900; i--) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        anoSelect.appendChild(option);
    }
}

// Chamar a função de preenchimento ao carregar a página
window.onload = preencherData;
