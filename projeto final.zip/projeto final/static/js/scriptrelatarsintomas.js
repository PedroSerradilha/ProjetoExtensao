function enviarSintomas() {
    const select = document.getElementById('sintomas');
    const sintomasSelecionados = Array.from(select.selectedOptions).map(option => option.text);

    if (sintomasSelecionados.length > 0) {
        alert(`Sintomas enviados: ${sintomasSelecionados.join(', ')}`);
        // Aqui você pode adicionar a lógica de envio para o servidor ou processamento
    } else {
        alert("Por favor, selecione pelo menos um sintoma.");
    }
}
