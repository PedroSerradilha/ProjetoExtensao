document.addEventListener("DOMContentLoaded", () => {
    // Criar o observer para as seções
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            // Se a seção entrar na tela
            if (entry.isIntersecting) {
                // Adiciona a classe 'visible' para exibir a seção
                entry.target.classList.add('visible');
                // Parar de observar esta seção
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.7 // O elemento será visível quando 50% dele estiver na tela
    });

    // Seleciona todas as seções e começa a observar
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        observer.observe(section);
    });
});
