// Atualizar pré-visualização da foto de perfil
/*document.getElementById("profile-picture-input").addEventListener("change", function(event) {
    const profilePreview = document.getElementById("profile-preview");
    const file = event.target.files[0];
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            profilePreview.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}); */

// Função para salvar alterações de configurações
function saveChanges() {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const firstName = document.getElementById('first_name').value;
    const lastName = document.getElementById('last_name').value;

    alert(`Alterações salvas com sucesso!\n
    Nome de Usuário: ${username}\n
    Email: ${email}\n
    Nome: ${firstName}\n
    Sobrenome: ${lastName}`);
    
    // Aqui você pode incluir código para enviar os dados para o servidor, se necessário.
}

// Função para deslogar o usuário
function logout() {
    alert("Você foi deslogado.");
    // Aqui você pode redirecionar o usuário para a página de login, por exemplo.
}
