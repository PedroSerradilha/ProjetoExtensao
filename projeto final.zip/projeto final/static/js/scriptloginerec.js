document.addEventListener("DOMContentLoaded", function() {
    // Evento de submissão do formulário de login
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const email = document.getElementById("email").value;
            const senha = document.getElementById("senha").value;

            if (email && senha) {
                alert("Login realizado com sucesso!");
            } else {
                alert("Por favor, preencha todos os campos.");
            }
        });
    }
});
