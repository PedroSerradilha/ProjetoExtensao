class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'  # Substitua pelo seu usuário
    MYSQL_PASSWORD = '1234'  # Substitua pela sua senha
    MYSQL_DB = 'bem_viver'  # Substitua pelo seu banco de dados
