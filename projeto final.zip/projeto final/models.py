from flask_sqlalchemy import SQLAlchemy
from models import db, Usuario  # Importa o banco de dados e o modelo Usuario

db = SQLAlchemy()

class Usuario(db.Model):
    __tablename__ = 'usuario'
    id_usuario = db.Column(db.Integer, primary_key=True)
    nome_usuario = db.Column(db.String(100), nullable=False)
    data_nascimento = db.Column(db.Date, nullable=False)
    sexo = db.Column(db.String(10), nullable=False)
    email_usuario = db.Column(db.String(50), unique=True, nullable=False)
    senha_usuario = db.Column(db.String(50), nullable=False)